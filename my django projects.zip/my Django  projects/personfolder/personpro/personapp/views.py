from django.shortcuts import render
def home(request):
    return render (request,'person_home.html')

def employee(request):
    return render (request,'person_emp.html')

def customer(request):
    return render(request,'person_customer.html')

def student(request):
    return render(request, 'person_student.html')





