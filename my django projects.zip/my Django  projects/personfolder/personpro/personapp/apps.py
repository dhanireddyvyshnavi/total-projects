from django.apps import AppConfig


class PersonappConfig(AppConfig):
    name = 'personapp'
