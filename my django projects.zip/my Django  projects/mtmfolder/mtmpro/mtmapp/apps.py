from django.apps import AppConfig


class MtmappConfig(AppConfig):
    name = 'mtmapp'
