from django.apps import AppConfig


class ProductsappConfig(AppConfig):
    name = 'productsapp'
