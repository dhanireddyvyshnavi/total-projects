from django.shortcuts import render
from django.http.response import HttpResponse


import datetime as dt
def date (request):
    d='<h1> The time and date is',dt.datetime.now(),'</h1>'
    return HttpResponse(d)


