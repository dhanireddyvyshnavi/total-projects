from django.shortcuts import render
from .forms import ContactForm
from django.http import HttpResponse


def ContactView(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            return HttpResponse('Data is inserted')
        else:
            return HttpResponse('Data is not Inserted')
        pass


    else:
        form = ContactForm()
        return render(request,'contactfile.html',{'form': form})





