from django.apps import AppConfig


class MultiappConfig(AppConfig):
    name = 'multiapp'
