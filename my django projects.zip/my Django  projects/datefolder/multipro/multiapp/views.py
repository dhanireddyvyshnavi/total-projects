from django.shortcuts import render
from .models import Student
from .forms import MultiSelectForm
from django.http import HttpResponse

def MultiSelectView(request):
    if request.method=='POST':
        form=MultiSelectForm(request.POST)
        if form.is_valid():
            sname=form.cleaned_data.get('sname')
            fee=form.cleaned_data.get('fee')
            gender=form.cleaned_data.get('gender')
            courses=form.cleaned_data.get('courses')
            dob=form.cleaned_data.get('dob')
            s=Student(sname=sname,
                      fee=fee,
                      gender=gender,
                      courses=courses,
                      dob=dob)
            s.save()
            form=MultiSelectForm()
            return render(request,'multi123.html',{'form':form})
        else:
            return HttpResponse('Data is not Inserted')
    else:
        form=MultiSelectForm()
        return render(request, 'multi123.html', {'form': form})







