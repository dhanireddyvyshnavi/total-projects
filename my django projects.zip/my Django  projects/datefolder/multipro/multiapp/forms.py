from django import forms
from multiselectfield import MultiSelectFormField
from django .forms.widgets import RadioSelect
from django .forms import extras


class MultiSelectForm (forms.Form):
    sname=forms.CharField(
        label='enter your name',
        widget=forms.TextInput(
            attrs={
                'class':'form-control',
                'placeholder':'name'
            }
        )
    )
    fee = forms.IntegerField(
        label='enter your fee',
        widget=forms.NumberInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'fee'
            }
        )
    )
    GENDER_CHOICES=(
        ('M','male'),
        ('F','female')
    )
    gender=forms.ChoiceField(
        widget=forms.RadioSelect(
    ),choices=GENDER_CHOICES)
    COURSES_CHOICES=(
        ('python', 'Python'),
        ('django', 'Django'),
        ('mysql', 'MySQL'),
        ('oracle', 'Oracle')

    )
    courses=MultiSelectFormField(choices=COURSES_CHOICES)
    years=range(2018,1970,-1)
    dob=forms.DateField(widget=forms.extras.SelectDateWidget(years=years))