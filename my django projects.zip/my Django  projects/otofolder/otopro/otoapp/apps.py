from django.apps import AppConfig


class OtoappConfig(AppConfig):
    name = 'otoapp'
