from django import forms

class contactform(forms.Form):
    name=forms.CharField(max_length=20)
    email=forms.EmailField(max_length=50)
    sal=forms.IntegerField()
