from django.apps import AppConfig


class BioappConfig(AppConfig):
    name = 'bioapp'
