from django.shortcuts import render
from .forms import RegistrationForm,LoginForm
from .models import Registration
from django.http import HttpResponse

def home(request):
    return render(request,'reglogin-home.html')

def Registrationview(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            firstname = request.POST.get('firstname','')
            lastname = request.POST.get('lastname','')
            username = request.POST.get('username','')
            password = request.POST.get('password','')
            email = request.POST.get('email','')
            mobilenumber = request.POST.get('mobilenumber','')
            gender = request.POST.get('gender','')
            r = Registration(firstname=firstname,
                                 lastname=lastname,
                                 username=username,
                                 password=password,
                                 email=email,
                                 mobilenumber=mobilenumber,
                                 gender=gender)
            r.save()
            form = RegistrationForm()
            return render(request,'reglogin-reg.html',{'form':form})

    else:
        form = RegistrationForm()
        return render(request,'reglogin-reg.html',{'form': form})

def Loginview(request):
    if request.method == 'POST':
        lform=LoginForm(request.POST)
        if lform.is_valid():
            username = request.POST.get('username', '')
            password = request.POST.get('password', '')
            user = Registration.objects.filter(username=username)
            pwd = Registration.objects.filter(password=password)
            if user and pwd:
                return HttpResponse('login success')
            else:
                return HttpResponse('login failed')
    else:
        lform = LoginForm()
        return render(request,'reglogin-login.html',{'lform':lform})






