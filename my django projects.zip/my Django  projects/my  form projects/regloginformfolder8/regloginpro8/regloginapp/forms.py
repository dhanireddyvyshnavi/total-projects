from django import forms

class RegForm(forms.Form):
    firstname = forms.CharField(
        label='enter your firstname',
        widget=forms.TextInput(
            attrs={
                'class':'form-control',
                'placeholder':'firstname'
            }
        )
    )
    lastname = forms.CharField(
        label='enter your lastname',
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'lastname'
            }
        )
    )
    usetrname = forms.CharField(
        label='enter your username',
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'username'
            }
        )
    )
    password = forms.CharField(
        label='enter your password',
        widget=forms.PasswordInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'password'
            }
        )
    )
    email = forms.EmailField(
        label='enter your email',
        widget=forms.EmailInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'email'
            }
        )
    )
    mobilenumber = forms.IntegerField(
        label='enter your mobilenumber',
        widget=forms.NumberInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'mobilenumber'
            }
        )
    )
    gender = forms.CharField(
        label='enter your gender',
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'gender'
            }
        )
    )
class LoginForm(forms.Form):
    usetrname = forms.CharField(
        label='enter your username',
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'username'
            }
        )
    )
    password = forms.CharField(
        label='enter your password',
        widget=forms.PasswordInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'password'
            }
        )
    )