from django.apps import AppConfig


class RegloginappConfig(AppConfig):
    name = 'regloginapp'
