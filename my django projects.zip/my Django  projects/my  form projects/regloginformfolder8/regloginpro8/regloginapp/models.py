from django.db import models

class Reglogin(models.Model):
    firstname=models.CharField(max_length=20)
    lastname=models.CharField(max_length=20)
    username=models.CharField(max_length=20,primary_key=True)
    password=models.CharField(max_length=20)
    email=models.EmailField(max_length=50,unique=True)
    mobilenumber=models.IntegerField()
    gender=models.CharField(max_length=20)
