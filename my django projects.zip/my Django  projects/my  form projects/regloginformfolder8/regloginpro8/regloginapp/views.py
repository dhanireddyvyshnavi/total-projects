from django.shortcuts import render
from django.http import HttpResponse
from .forms import RegForm,LoginForm
from .models import Reglogin

def Home(request):
    return render(request,'homereglogin.html')

def Registrationview(request):
    if request.method == 'POST':
        form = RegForm(request.POST)
        if form.is_valid():
            firstname = request.POST.get('firstname','')
            lastname = request.POST.get('lastname','')
            username = request.POST.get('username','')
            password = request.POST.get('password','')
            email = request.POST.get('email','')
            mobilenumber = request.POST.get('mobilenumber','')
            gender = request.POST.get('gender','')
            r = Reglogin(firstname=firstname,
                                 lastname=lastname,
                                 username=username,
                                 password=password,
                                 email=email,
                                 mobilenumber=mobilenumber,
                                 gender=gender)
            r.save()
            rform = RegForm()
            return render(request,'regform.html',{'rform':rform})

    else:
        rform = RegForm()
        return render(request,'regform.html',{'rform': rform})

def Loginview(request):
    if request.method == 'POST':
        lform=LoginForm(request.POST)
        if lform.is_valid():
            username = request.POST.get('username', '')
            password = request.POST.get('password', '')
            user = Reglogin.objects.filter(username=username)
            pwd = Reglogin.objects.filter(password=password)
            if user and pwd:
                return HttpResponse('login success')
            else:
                return HttpResponse('login failed')
    else:
        lform = LoginForm()
        return render(request,'loginform.html',{'lform':lform})



