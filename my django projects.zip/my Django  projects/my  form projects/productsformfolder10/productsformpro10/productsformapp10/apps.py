from django.apps import AppConfig


class Productsformapp10Config(AppConfig):
    name = 'productsformapp10'
