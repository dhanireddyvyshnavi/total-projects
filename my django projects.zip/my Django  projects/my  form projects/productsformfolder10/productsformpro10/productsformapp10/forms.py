from django import forms

class ProductForm(forms.Form):
    pid=forms.IntegerField(
        label='enter your product Id',
        widget=forms.NumberInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'product Id'
            }

        )

    )
    pname=forms.CharField(
        label='enter your product name',
        widget=forms.TextInput(
            attrs={
                'class':'form-control',
                'placeholder':'product name'
            }
        )
    )
    pcost=forms.IntegerField(
        label='enter your product cost',
        widget=forms.NumberInput(
            attrs={
                'class':'form-control',
                'placeholder':'product cost'
            }
        )
    )
    pcolor=forms.CharField(
        label='entetr your product color',
        widget=forms.TextInput(
            attrs={
                'class':'form-control',
                'placeholder':'product color'
            }

        )
    )
    pclass=forms.CharField(
        label='enter your product class',
        widget=forms.TextInput(
            attrs={
                'class':'form-control',
                'placeholder':'product class'
            }
        )
    )
    quantity=forms.IntegerField(
        label='enter your product quantity',
        widget=forms.NumberInput(
            attrs={
                'class':'form-control',
                'placeholder':'product quantity'
            }
        )
    )
class UpdatedForm(forms.Form):
    pid=forms.IntegerField(
        label='enter your product Id',
        widget=forms.NumberInput(
            attrs={
                'class':'form-control',
                'placeholder':'product Id'
            }
        )
    )
    pcost=forms.IntegerField(
        label='enter your product cost',
        widget=forms.NumberInput(
            attrs={
                'class':'form-control',
                'placeholder':'product cost'
            }
        )
    )
class DeleteForm(forms.Form):
    pid=forms.IntegerField(
        label='enter product Id',
        widget=forms.NumberInput(
            attrs={
                'class':'form-control',
                'placeholder':'product Id'
            }
        )
    )