from django.apps import AppConfig


class Simpleapp1Config(AppConfig):
    name = 'simpleapp1'
