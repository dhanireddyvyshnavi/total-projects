from django.shortcuts import render
from django.http import HttpResponse
from .forms import SimpleForm

def Simple(request):
    if request.method=='POST':
        form=SimpleForm(request.POST)
        if form.is_valid():
            return HttpResponse('Data inserted')
        else:
            return HttpResponse('Data is not inserted')
    else:
        form=SimpleForm()
        return render(request,'simple.html',{'form':form})
