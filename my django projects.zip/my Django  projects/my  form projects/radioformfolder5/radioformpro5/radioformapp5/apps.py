from django.apps import AppConfig


class Radioformapp5Config(AppConfig):
    name = 'radioformapp5'
