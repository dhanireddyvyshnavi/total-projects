from django.db import models
from multiselectfield import MultiSelectField

class Student(models.Model):
    sname=models.CharField(max_length=20)
    fee=models.IntegerField()
    GENDER_CHOICES=(
        ('M','male'),
        ('F','female')
    )
    gender=models.CharField(max_length=1,choices=GENDER_CHOICES)
    COURSES_CHOICES=(
        ('python','Python'),
        ('django','Django'),
        ('mysql','MySQL'),
        ('oracle','Oracle')
    )
    courses=MultiSelectField(choices=COURSES_CHOICES)
    dob=models.DateField(max_length=50)


