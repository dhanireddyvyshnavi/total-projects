from django.db import models

class Address(models.Model):
    name=models.CharField(max_length=20)
    fathername=models.CharField(max_length=20)
    landmark=models.CharField(max_length=20)
    pin=models.IntegerField()
    village=models.CharField(max_length=20)
    dist=models.CharField(max_length=20)
    state=models.CharField(max_length=20)