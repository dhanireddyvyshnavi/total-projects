from django.shortcuts import render
from django.http import HttpResponse
from .models import Address
from .forms import AddressForm

def AddressView(request):
    if request.method=='POST':
        form=AddressForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponse('data inserted')
        else:
            return HttpResponse('data is not inserted')

    else:
        form=AddressForm()
        return render(request,'addresfile.html',{'form':form})