from django.apps import AppConfig


class Addressformapp6Config(AppConfig):
    name = 'addressformapp6'
