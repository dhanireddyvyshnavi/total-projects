from django.apps import AppConfig


class Regformapp7Config(AppConfig):
    name = 'regformapp7'
