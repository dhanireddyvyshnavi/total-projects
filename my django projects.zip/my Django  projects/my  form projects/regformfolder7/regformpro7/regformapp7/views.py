from django.shortcuts import render
from django.http import HttpResponse
from .forms import RegForm
from .models import Reg


def RegView(request):
    if request.method=='POST':
        form=RegForm(request.POST)
        if form.is_valid():
            firstname=request.POST.get('firstname','')
            lastname=request.POST.get('lastname','')
            email=request.POST.get('email','')
            salary=request.POST.get('salary','')
            comm=request.POST.get('comm','')
            location=request.POST.get('location','')
            company=request.POST.get('company','')
            data=Reg(firstname=firstname,
                     lastname=lastname,
                     email=email,
                     salary=salary,
                     comm=comm,
                     location=location,
                     company=company)
            data.save()
            form=RegForm()
            return render(request, 'reg.html', {'form': form})

    else:
        form=RegForm()
        return render(request,'reg.html',{'form':form})

