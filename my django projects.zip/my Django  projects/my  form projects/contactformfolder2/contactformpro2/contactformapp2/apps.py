from django.apps import AppConfig


class Contactformapp2Config(AppConfig):
    name = 'contactformapp2'
