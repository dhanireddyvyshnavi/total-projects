from django import forms

class ContactForm(forms.Form):
    name=forms.CharField(
        label='enter your name',
        widget=forms.TextInput(
            attrs={
                'class':'form-control',
                'placeholder':'name'
            }
        )
    )
    salary = forms.IntegerField(
        label='enter your salary',
        widget=forms.NumberInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'salary'
            }
        )
    )
    location = forms.CharField(
        label='enter your location',
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'location'
            }
        )
    )
    email = forms.EmailField(
        label='enter your email',
        widget=forms.EmailInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'email'
            }
        )
    )
    username = forms.CharField(
        label='enter your username',
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'username'
            }
        )
    )
    password = forms.CharField(
        label='enter your password',
        widget=forms.PasswordInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'password'
            }
        )
    )
