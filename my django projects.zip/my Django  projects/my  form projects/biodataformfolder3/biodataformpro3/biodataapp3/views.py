from django.shortcuts import render
from django.http import HttpResponse
from .forms import BiodataForm


def Biodata(request):
    if request.method=='POST':
        form=BiodataForm(request.POST)
        if form.is_valid():
            return HttpResponse('Data Inserted')
        else:
            return HttpResponse('Data is not Inserted')

    else:
        form=BiodataForm()
        return render(request,'biodatafile.html',{'form':form})
