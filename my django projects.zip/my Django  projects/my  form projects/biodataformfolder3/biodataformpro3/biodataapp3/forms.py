from django import forms

class BiodataForm(forms.Form):
    firstname=forms.CharField(
        label='enter your firstname',
        widget=forms.TextInput(
            attrs={
                'class':'form-control',
                'placeholder':'firstname'
            }
        )
    )
    lastname = forms.CharField(
        label='enter your lastname',
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'lastname'
            }
        )
    )
    collegename=forms.CharField(
            label='enter your collegename',
            widget=forms.TextInput(
                attrs={
                    'class':'form-control',
                    'placeholder':'collegetname'
                }
            )
        )
    qualification=forms.CharField(
            label='enter your qualification',
            widget=forms.TextInput(
                attrs={
                    'class':'form-control',
                    'placeholder':'qualification'
                }
            )
        )
    persentage=forms.IntegerField(
            label='enter your persentage',
            widget=forms.NumberInput(
                attrs={
                    'class':'form-control',
                    'placeholder':'persentage'
                }
            )
        )
    gender=forms.CharField(
            label='enter your gender',
            widget=forms.TextInput(
                attrs={
                    'class':'form-control',
                    'placeholder':'gender'
                }
            )
        )
    dateofbirth=forms.IntegerField(
            label='enter your DOB',
            widget=forms.NumberInput(
                attrs={
                    'class':'form-control',
                    'placeholder':'DOB'
                }
            )
        )
    age=forms.IntegerField(
            label='enter your age',
            widget=forms.NumberInput(
                attrs={
                    'class':'form-control',
                    'placeholder':'age'
                }
            )
        )
    address=forms.CharField(
            label='enter your address',
            widget=forms.TextInput(
                attrs={
                    'class':'form-control',
                    'placeholder':'address'
                }
            )
        )

