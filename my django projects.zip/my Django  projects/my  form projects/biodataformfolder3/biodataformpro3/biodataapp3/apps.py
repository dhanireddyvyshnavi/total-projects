from django.apps import AppConfig


class Biodataapp3Config(AppConfig):
    name = 'biodataapp3'
