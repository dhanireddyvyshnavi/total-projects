from django.shortcuts import render
from .models import Personal
from .forms import PersonalForm
from django.http import HttpResponse

def PersonalView(request):
    if request.method=='POST':
        form=PersonalForm(request.POST)
        if form.is_valid():
            Name = request.POST.get('Name','')
            FatherName = request.POST.get('FatherName','')
            Location = request.POST.get('Location','')
            Email = request.POST.get('Email','')
            MobileNumber = request.POST.get('MobileNumber','')
            f = Personal(Name=Name,
                         FatherName=FatherName,
                         Location=Location,
                         Email=Email,
                         MobileNumber=MobileNumber)
            f.save()
            form = PersonalForm()
            return render(request,'personalfile.html',{'form': form})

    else:
        form=PersonalForm()
        return render(request,'personalfile.html',{'form':form})

def Display(request):
    data = Personal.objects.all()
    return render(request, 'display.html', {'data': data})


