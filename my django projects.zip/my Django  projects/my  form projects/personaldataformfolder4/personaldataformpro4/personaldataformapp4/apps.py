from django.apps import AppConfig


class Personaldataformapp4Config(AppConfig):
    name = 'personaldataformapp4'
