from django import forms


class PersonalForm(forms.Form):
    Name=forms.CharField(
        label='enter your name',
        widget=forms.TextInput(
            attrs={
                'class':'form-control',
                'placeholder':'name'
            }
        )
    )
    FatherName = forms.CharField(
        label='enter your fathername',
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'fathername'
            }
        )
    )

    Location = forms.CharField(
        label='enter your location',
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'location'
            }
        )
    )
    Email = forms.CharField(
        label='enter your email',
        widget=forms.EmailInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'email'
            }
        )
    )
    MobileNumber = forms.IntegerField(
        label='enter your mobilenumber',
        widget=forms.NumberInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'mobilenumber'
            }
        )
    )