from django.apps import AppConfig


class Feedbackformapp9Config(AppConfig):
    name = 'feedbackformapp9'
