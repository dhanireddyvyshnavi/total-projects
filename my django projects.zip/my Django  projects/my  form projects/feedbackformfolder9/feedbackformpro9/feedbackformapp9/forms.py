from django import forms

class FeedbackForm(forms.Form):
    name=forms.CharField(
        label='enter your name',
        widget=forms.TextInput(
            attrs={
                'class':'form-control',
                'placeholder':'name'
            }
        )
    )
    rating=forms.IntegerField(
        label='enter your rating between 1 and 5',
        widget=forms.NumberInput(
            attrs={
                'class':'form-control',
                'placeholder':'rating'
            }
        )
    )
    feedback=forms.CharField(
        label='enter your feedback',
        widget=forms.Textarea(
            attrs={
                'class':'form-control',
                'placeholder':'feedback'
            }
        )
    )