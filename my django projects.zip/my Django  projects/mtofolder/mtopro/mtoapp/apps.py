from django.apps import AppConfig


class MtoappConfig(AppConfig):
    name = 'mtoapp'
