from django import forms

class RegistrationForm(forms.Form):
    firstname = forms.CharField(
        label='enter your firstname',
        widget=forms.TextInput(
            attrs={
                'class':'form-control',
                'placeholder':'firstname'
            }
        )
    )
    lastname = forms.CharField(
        label='enter your lastname',
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'lastname'
            }
        )
    )

    email = forms.EmailField(
        label='enter your email',
        widget=forms.EmailInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'email'
            }
        )
    )
    salary = forms.IntegerField(
        label='enter your salary',
        widget=forms.NumberInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'salary'
            }
        )
    )

    comm = forms.IntegerField(
        label='enter your commition',
        widget=forms.NumberInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'commition'
            }
        )
    )

    location = forms.CharField(
        label='enter your location',
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'location'
            }
        )
    )
    company = forms.CharField(
        label='enter your company',
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'company'
            }
        )
    )

