from django.db import models

class Registration(models.Model):

            firstname = models.CharField(max_length=20)
            lastname = models.CharField(max_length=20)
            email = models.EmailField(max_length=50)
            salary = models.IntegerField()
            comm = models.IntegerField()
            location = models.CharField(max_length=20)
            company = models.CharField(max_length=20)