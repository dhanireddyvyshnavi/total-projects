from django.shortcuts import render
from .forms import RegistrationForm
from .models import Registration
from django.http import HttpResponse

def Registrationview(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            firstname = request.POST.get('firstname','')
            lastname = request.POST.get('lastname','')
            email = request.POST.get('email','')
            salary = request.POST.get('salary','')
            comm = request.POST.get('comm','')
            location = request.POST.get('location','')
            company = request.POST.get('company','')

            r = Registration(firstname=firstname,
                                 lastname=lastname,
                             email=email,
                             salary=salary,
                             comm=comm,
                             location=location,
                             company=company)
            r.save()
            form = RegistrationForm()
            return render(request,'reg-reg.html',{'form':form})

    else:
        form = RegistrationForm()
        return render(request,'reg-reg.html',{'form': form})





