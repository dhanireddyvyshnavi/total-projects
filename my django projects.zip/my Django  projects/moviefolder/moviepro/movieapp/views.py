from django.shortcuts import render
from .forms import MovieForm
from .models import MovieData
from django.http import HttpResponse

def home(request):
    return render(request,'movie_home.html')

def insert(request):
    if request.method=='POST':
        form = MovieForm(request.POST)
        if form.is_valid():
            hero = request.POST.get('hero','')
            heroine = request.POST.get('heroine','')
            director = request.POST.get('director','')
            producer = request.POST.get('producer','')
            numberofdays = request.POST.get('numberofdays','')
            collections = request.POST.get('collections','')
            ratings = request.POST.get('ratings','')
            # releasedate = request.POST.get('releasedate','')
            releasedate = form.cleaned_data.get('releasedate','')


            mdata = MovieData(hero=hero,
                              heroine=heroine,
                              director=director,
                              producer=producer,
                              numberofdays=numberofdays,
                              collections=collections,
                              ratings=ratings,
                              releasedate=releasedate)
            mdata.save()
            form = MovieForm()
            return render(request, 'movie_insert.html', {'form': form})


    else:
        form = MovieForm()
        return render(request,'movie_insert.html',{'form':form})

def display(request):
    data = MovieData.objects.all()
    return render(request,'Movie_display.html',{'data':data})