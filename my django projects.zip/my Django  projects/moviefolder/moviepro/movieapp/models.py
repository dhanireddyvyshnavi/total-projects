from django.db import models

class MovieData(models.Model):
    hero = models.CharField(max_length=20)
    heroine = models.CharField(max_length=20)
    director = models.CharField(max_length=20)
    producer = models.CharField(max_length=20)
    numberofdays = models.IntegerField()
    collections = models.IntegerField()
    ratings = models.IntegerField()
    releasedate = models.DateField()
