from django import forms
from django.forms import extras
class MovieForm(forms.Form):
    hero = forms.CharField(
        label='Hero',
        widget=forms.TextInput(
            attrs={
                'class':'form-control',
                'placeholder':'Hero Name'
            }
        )
    )
    heroine = forms.CharField(
        label='Heroine',
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Heroine Name'
            }
        )
    )
    director = forms.CharField(
        label='Director',
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Director Name'
            }
        )
    )
    producer = forms.CharField(
        label='Producer',
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Producer Name'
            }
        )
    )
    numberofdays = forms.IntegerField(
        label='No. Of Days',
        widget=forms.NumberInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Days'
            }
        )
    )
    collections = forms.IntegerField(
        label='Collections',
        widget=forms.NumberInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'collections '
            }
        )
    )
    ratings = forms.IntegerField(
        label='Ratings',
        widget=forms.NumberInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Ratings'
            }
        )
    )
    years=range(2018,1970,-1)
    releasedate = forms.DateField(widget=forms.extras.SelectDateWidget(years=years))




