from django.apps import AppConfig


class Person2AppConfig(AppConfig):
    name = 'person2app'
