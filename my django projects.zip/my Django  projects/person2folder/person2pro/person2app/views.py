from django.shortcuts import render
from .forms import PersonalForm
from .models import Personal
from django.http import HttpResponse

def PersonalView(request):
    if request.method=='POST':
        form=PersonalForm(request.POST)
        if form.is_valid():
            Name = request.POST.get('Name', '')
            FatherName = request.POST.get('FatherName', '')
            Location = request.POST.get('Location', '')
            Email = request.POST.get('Email', '')
            MobileNumber = request.POST.get('MobileNumber', '')
            r = Personal(Name=Name,
                         FatherName=FatherName,
                         Location=Location,
                         Email=Email,
                         MobileNumber=MobileNumber)
            r.save()
            form = PersonalForm()
            return render(request, 'personalfile.html', {'form': form})
    else:
        form=PersonalForm()
        return render(request,'personalfile.html',{'form':form})

def display(request):
   data=Personal.objects.all()
   return render(request, 'bpersonalfile.html', {'data': data})
