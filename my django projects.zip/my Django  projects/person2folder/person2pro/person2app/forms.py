from django import forms

class PersonalForm(forms.Form):
    Name = forms.CharField(
        label='enter your Name',
        widget=forms.TextInput(
            attrs={
                'class':'form-control',
                'placeholder':'Name'
            }
        )
    )
    FatherName = forms.CharField(
        label='enter your Father Name',
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Father Name'
            }
        )
    )
    Location = forms.CharField(
        label='enter your Location',
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Location'
            }
        )
    )
    Email = forms.EmailField(
        label='enter your Email',
        widget=forms.EmailInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Email'
            }
        )
    )

    MobileNumber = forms.IntegerField(
        label='enter your MobileNumber',
        widget=forms.NumberInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'MobileNumber'
            }
        )
    )

