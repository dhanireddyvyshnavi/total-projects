from django.apps import AppConfig


class FilesappConfig(AppConfig):
    name = 'filesapp'
