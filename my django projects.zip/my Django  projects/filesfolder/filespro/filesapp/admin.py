from django.contrib import admin
from .models import Student

class studentadmin(admin.ModelAdmin):
    list_display = ('sno',
                    'sname',
                    'sloc',
                    'image',
                    'profile')
admin.site.register(Student,studentadmin)