from django.shortcuts import render
from django.http import HttpResponse

def index(request):
    return HttpResponse('<h4>Cookie was first by a programmer'
                        'named Louis Montulli in 1994 <br>'
                        'at NetScape Communications'
                        'in their NetScape Browser</h4>')
def test_cookie(request):
    if not request.COOKIES.get('color'):
        response=HttpResponse('cookie set')
        response.set_cookie('color','blue')
        return response
    else:
        return HttpResponse('your favorite'
                            'color is {0}'.format(request .COOKIES['color']))
def count_cookie(request):
    if not request.COOKIES.get('visits'):
        response=HttpResponse('This is your first visit to the site'
                              'from now on 1 will track'
                              'your visits to this site.')
        response.set_cookie('visits','1')
    else:
        visits=int(request.COOKIES.get('visits'))+1
        response=HttpResponse('This is your{0} visit'.
                              format(visits))
        response.set_cookie('visits',str(visits))
    return response

def delete_cookie(request):
    if request.COOKIES.get('visits'):
        response=HttpResponse('cookies cleared')
        response.delete_cookie('visits')
    else:
        response=HttpResponse('we are not tracking you.')
    return response