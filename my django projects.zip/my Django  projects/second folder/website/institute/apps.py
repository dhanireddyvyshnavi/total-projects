from django.apps import AppConfig


class InstituteConfig(AppConfig):
    name = 'institute'
