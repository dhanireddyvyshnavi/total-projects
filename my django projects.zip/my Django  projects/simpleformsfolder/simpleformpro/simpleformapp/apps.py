from django.apps import AppConfig


class SimpleformappConfig(AppConfig):
    name = 'simpleformapp'
