from django import forms

class SimpleForm(forms.Form):
    name=forms.CharField(max_length=20)
    email=forms.EmailField(max_length=50)
    sal=forms.IntegerField()
    loc=forms.CharField(max_length=30)
