from django.apps import AppConfig


class DurgasoftappConfig(AppConfig):
    name = 'durgasoftapp'
