from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import View

class Morning(View):
    greeting="Good Morning"
    def get(self,request):
        return HttpResponse(Morning.greeting)
class Evening(View):
    greeting="Good Evening"
    def get(self,request):
        return HttpResponse(Evening.greeting)
