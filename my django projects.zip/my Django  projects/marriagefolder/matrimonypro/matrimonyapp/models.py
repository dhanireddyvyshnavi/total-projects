from django.db import models
from multiselectfield import MultiSelectField

class MatrimonyData(models.Model):
    first_name=models.CharField(max_length=100)
    last_name=models.CharField(max_length=220)
    father_name=models.CharField(max_length=220)
    mother_name=models.CharField(max_length=220)

    sal=models.IntegerField()
    mobile=models.BigIntegerField(unique=True)
    color=models.CharField(max_length=220)
    weight=models.IntegerField()

    email=models.EmailField(unique=True)
    username=models.CharField(max_length=220,unique=True)
    password1=models.CharField(max_length=220)
    password2=models.CharField(max_length=220)
    dob=models.DateField(max_length=220)
    height=models.FloatField()


    GENDER_CHOICES=(
        ('M','Male'),
        ('F','Female')
    )
    gender=models.CharField(max_length=1,choices=GENDER_CHOICES)

    LOCATION_CHOICES=(
        ('Hyd','Hyderabad'),
        ('Bang','Bangalore'),
        ('chen','Chennai'),
        ('Mum','Mumbai')
    )
    loc = MultiSelectField(max_length=200,choices=LOCATION_CHOICES)

    JOB_CHOICES=(
        ('Govt','Govt job'),
        ('S/W','Software'),
        ('Trainers','Teachers'),
        ('Doctor','Doctor'),
        ('Police','Police')
    )
    jobtype=MultiSelectField(max_length=200,choices=JOB_CHOICES)

    LOOKING_CHOICES=(
        ('M','Boy'),
        ('F','Girl')
    )
    looking_for=models.CharField(max_length=1,choices=LOOKING_CHOICES)

    address=models.CharField(max_length=500)


