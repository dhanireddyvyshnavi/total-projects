from django import forms
from multiselectfield import MultiSelectFormField

class RegistrationForm(forms.Form):
    first_name=forms.CharField(
        label='First Name',
        widget=forms.TextInput(
            attrs={
                'class':'form-control',
                'placeholder':'First Name'
            }
        )
    )

    last_name=forms.CharField(
        label='Last Name',
        widget=forms.TextInput(
            attrs={
                'class':'form-control',
                'placeholder':'Last Name'
            }
        )
    )

    father_name=forms.CharField(
        label='Father Name',
        widget=forms.TextInput(
            attrs={
                'class':'form-control',
                'placeholder':'Father Name'
            }
        )
    )

    mother_name=forms.CharField(
        label='Mother Name',
        widget=forms.TextInput(
            attrs={
                'class':'form-control',
                'placeholder':'Mother Name'
            }
        )
    )

    salary=forms.IntegerField(
        label='Salary',
        widget=forms.NumberInput(
            attrs={
                'class':'form-control',
                'placeholder':'Salary'
            }
        )
    )

    mobile=forms.IntegerField(
        label='Mobile',
        widget=forms.NumberInput(
            attrs={
                'class':'form-control',
                'placeholder':'Mobile'
            }
        )
    )

    color=forms.CharField(
        label='Color',
        widget=forms.TextInput(
            attrs={
                'class':'form-control',
                'placeholder':'Color'
            }
        )
    )

    weight=forms.IntegerField(
        label='Weight',
        widget=forms.NumberInput(
            attrs={
                'class':'form-control',
                'placeholder':'Weight'
            }
        )
    )

    email=forms.EmailField(
        label='Email',
        widget=forms.EmailInput(
            attrs={
                'class':'form-control',
                'placeholder':'Email'
            }
        )
    )

    username=forms.CharField(
        label='Username',
        widget=forms.TextInput(
            attrs={
                'class':'form-control',
                'placeholder':'Username'
            }
        )
    )

    password1=forms.CharField(
        label='Password',
        widget=forms.PasswordInput(
            attrs={
                'class':'form-control',
                'placeholder':'Password'
            }
        )
    )

    password2=forms.CharField(
        label='Confirm Password',
        widget=forms.PasswordInput(
            attrs={
                'class':'form-control',
                'placeholder':'Confirm Password'
            }
        )
    )

    year=range(1970,2001)

    dob=forms.DateField(
        widget=forms.SelectDateWidget(years=year)
    )

    height1=[4.5,4.6,4.7,4.8,4.9,4.10,4.11,5.0,5.1,5.2,5.3,5.4,5.5,5.6,5.7,5.8,5.9,5.10,5.11,6.0,6.1,6.2]

    HEIGHT_CHOICES=[tuple([x,x]) for x in height1]

    height=forms.FloatField(
        label='Height',
        widget=forms.Select(
            choices=HEIGHT_CHOICES,
            attrs={
                'class':'form-control'
            }
        )
    )

    GENDER_CHOICES = (
        ('M', 'Male'),
        ('F', 'Female')
    )
    gender=forms.ChoiceField(
        widget=forms.RadioSelect(),choices=GENDER_CHOICES)

    LOCATION_CHOICES = (
        ('Hyd', 'Hyderabad'),
        ('Bang', 'Bangalore'),
        ('chen', 'Chennai'),
        ('Mum', 'Mumbai')
    )
    loc = MultiSelectFormField(max_length=200 , choices=LOCATION_CHOICES)

    JOB_CHOICES = (
        ('Govt', 'Govt job'),
        ('S/W', 'Software'),
        ('Trainers', 'Teachers'),
        ('Doctor', 'Doctor'),
        ('Police', 'Police')
    )

    jobtype=MultiSelectFormField(max_length=200 , choices=JOB_CHOICES)

    LOOKING_CHOICES = (
        ('M', 'Boy'),
        ('F', 'Girl')
    )
    looking_for=forms.ChoiceField(
        widget=forms.RadioSelect(),choices=LOOKING_CHOICES)

    address = forms.CharField(
        label='Address',
        widget=forms.Textarea(
            attrs={
                'class': 'form-control',
                'placeholder': 'Address'
            }
        )
    )

class LoginForm(forms.Form):
    username = forms.CharField(
        label='Username',
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Username'
            }
        )
    )

    password = forms.CharField(
        label='Password',
        widget=forms.PasswordInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Password'
            }
        )
    )





