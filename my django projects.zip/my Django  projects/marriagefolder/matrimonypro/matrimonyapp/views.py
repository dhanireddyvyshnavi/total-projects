from django.shortcuts import render,redirect,HttpResponse
# from django.http.response import HttpResponse
from .forms import RegistrationForm,LoginForm
from .models import MatrimonyData



def loginview(request):
    if request.method=='POST':
        lform=LoginForm(request.POST)
        if lform.is_valid():
            lusername=request.POST.get('username','')
            lpassword=request.POST.get('password','')

            user=MatrimonyData.objects.filter(username=lusername)
            pwd=MatrimonyData.objects.filter(password1=lpassword)
            if user and pwd:
                return redirect('/registration/')
            else:
                return redirect('/login/')
    else:
        lform = LoginForm()
        return render(request, 'login_matri_backup.html', {'lform': lform})


def registrationview(request):
    if request.method == 'POST':
        form=RegistrationForm(request.POST)
        if form.is_valid():
            first_name=form.cleaned_data.get('first_name')
            last_name=form.cleaned_data.get('last_name')
            father_name=form.cleaned_data.get('father_name')
            mother_name=form.cleaned_data.get('mother_name')
            sal=form.cleaned_data.get('salary')
            mobile=form.cleaned_data.get('mobile')
            color=form.cleaned_data.get('color')
            weight=form.cleaned_data.get('weight')
            email=form.cleaned_data.get('email')
            username=form.cleaned_data.get('username')
            password1=form.cleaned_data.get('password1')
            password2=form.cleaned_data.get('password2')
            dob=form.cleaned_data.get('dob')
            height=form.cleaned_data.get('height')
            gender=form.cleaned_data.get('gender')

            loc =form.cleaned_data.get('loc')
            jobtype=form.cleaned_data.get('jobtype')
            looking_for=form.cleaned_data.get('looking_for')
            address=form.cleaned_data.get('address')
            m = MatrimonyData(first_name=first_name,
                              last_name=last_name,
                              father_name=father_name,
                              mother_name=mother_name,
                              sal=sal,
                              mobile=mobile,
                              color=color,
                              weight=weight,
                              email=email,
                              username=username,
                              password1=password1,
                              password2=password2,
                              dob=dob,
                              height=height,
                              gender=gender,
                              loc=loc,
                              jobtype=jobtype,
                              looking_for=looking_for,
                              address=address
                              )
            m.save()
            form = RegistrationForm()
            return render(request, 'reg_form.html', {'form': form})

        else:
            return HttpResponse('Data is not Inserted')


    else:
        form=RegistrationForm()
        return render(request,'reg_form.html',{'form':form})
