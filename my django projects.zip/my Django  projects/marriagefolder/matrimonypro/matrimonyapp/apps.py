from django.apps import AppConfig


class MatrimonyappConfig(AppConfig):
    name = 'matrimonyapp'
