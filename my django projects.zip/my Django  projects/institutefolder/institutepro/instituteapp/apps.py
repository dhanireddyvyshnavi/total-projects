from django.apps import AppConfig


class InstituteappConfig(AppConfig):
    name = 'instituteapp'
