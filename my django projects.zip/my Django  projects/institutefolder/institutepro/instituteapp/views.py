from django.shortcuts import render


def institute(request):
    return render(request,'institute.html')



