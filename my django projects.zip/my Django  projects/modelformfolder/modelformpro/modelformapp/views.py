from django.shortcuts import render
from .forms import AddressForm
from .models import Address
from django.http import HttpResponse


def AddressView(request):
    if request.method=='POST':
        form=AddressForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponse('Data inserted')
        else:
            return HttpResponse('Data is not inserted')
    else:
        form=AddressForm()
        return render(request,'addressfile.html',{'form':form})





