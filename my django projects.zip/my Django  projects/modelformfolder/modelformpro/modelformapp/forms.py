from django import forms
from .models import Address

class AddressForm(forms.ModelForm):
    class Meta:
        model=Address
        fields=['name','fname','landmark','pin','village','dist','state']