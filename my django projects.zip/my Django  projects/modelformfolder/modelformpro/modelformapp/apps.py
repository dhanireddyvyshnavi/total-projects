from django.apps import AppConfig


class ModelformappConfig(AppConfig):
    name = 'modelformapp'
